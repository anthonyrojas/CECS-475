﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Messaging;

namespace CustomerMaintenance.Messages
{
    public class DataMessage : MessageBase
    {
        public string CommandText { get; set; }
        public Customer CustomerMsg { get; set; }
        public int? IDText { get; set; }
        public string NameText { get; set; }
        public string AddressText { get; set; }
        public string CityText { get; set; }
        public string StateText { get; set; }
        public string ZipCodeText { get; set; }
    }
}
