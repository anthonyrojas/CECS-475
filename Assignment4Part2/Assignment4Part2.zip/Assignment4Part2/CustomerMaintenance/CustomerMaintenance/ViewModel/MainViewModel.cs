using GalaSoft.MvvmLight;
using CustomerMaintenance.Model;
using System.Windows.Input;
using System.Data;
using GalaSoft.MvvmLight.Messaging;
using GalaSoft.MvvmLight.Threading;
using GalaSoft.MvvmLight.Command;
using CustomerMaintenance.Views;
using System.Windows;
using System.Linq;
using System;
using CustomerMaintenance.Messages;
using System.Data.Entity.Infrastructure;
using System.Data.Entity;

namespace CustomerMaintenance.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        
        private string name;
        private string address;
        private string city;
        private string state;
        private string zip;
        private string id;
        static Customer selectedCustomer;
        public ICommand ShowModifyCommand { get; private set; }
        public ICommand ShowAddCommand { get; private set; }
        public ICommand DeleteCustomerCommand { get; private set; }
        public ICommand ExitCommand { get; private set; }
        public ICommand GetCustomerCommand { get; private set; }
        /// <summary>
        /// Initializes a new instance of the MainViewModel class.
        /// </summary>
        public MainViewModel()
        {
            ShowModifyCommand = new RelayCommand(ShowModifyMethod);
            ShowAddCommand = new RelayCommand(ShowAddMethod);
            DeleteCustomerCommand = new RelayCommand(DeleteCustomerMethod);
            ExitCommand = new RelayCommand(ExitMethod);
            GetCustomerCommand = new RelayCommand(GetCustomerMethod);
            Messenger.Default.Register<DataMessage>(this, OnReceiveMessageAction);
        }

        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                RaisePropertyChanged("Name");
            }
        }

        public string Address
        {
            get { return address; }
            set
            {
                address = value;
                RaisePropertyChanged("Address");
            }
        }

        public string City
        {
            get { return city; }
            set
            {
                city = value;
                RaisePropertyChanged("City");
            }
        }

        public string State
        {
            get { return state; }
            set
            {
                state = value;
                RaisePropertyChanged("State");
            }
        }

        public string ZipCode
        {
            get { return zip; }
            set
            {
                zip = value;
                RaisePropertyChanged("ZipCode");
            }
        }

        public string ID
        {
            get { return id; }
            set
            {
                id = value;
                RaisePropertyChanged("ID");
            }
        }

        public void OnReceiveMessageAction(DataMessage m)
        {
            if (m.CommandText == "Modifications Complete")
            {
                var query = from cust in MMABookEntity.BookEntity.Customers where cust.CustomerID == m.IDText select cust;
                selectedCustomer = query.FirstOrDefault();
                id = selectedCustomer.CustomerID.ToString();
                name = selectedCustomer.Name;
                address = selectedCustomer.Address;
                city = selectedCustomer.City;
                state = selectedCustomer.State;
                zip = selectedCustomer.ZipCode;
            }
            else if (m.CommandText == "Deleted")
            {
                id = m.IDText.ToString();
                name = m.NameText;
                address = m.AddressText;
                city = m.CityText;
                state = m.StateText;
                zip = m.ZipCodeText;
            }
            RaisePropertyChanged("Name");
            RaisePropertyChanged("Address");
            RaisePropertyChanged("City");
            RaisePropertyChanged("State");
            RaisePropertyChanged("ID");
            RaisePropertyChanged("ZipCode");
        }

        public void ShowAddMethod()
        {
            var addView = new AddView();
            addView.Show();
        }

        public void ShowModifyMethod()
        {
            if(selectedCustomer == null)
            {
                MessageBox.Show("Select a customer first");
            }
            else
            {
                DataMessage m = new DataMessage()
                {
                    CommandText = "Modify",
                    CustomerMsg = selectedCustomer
                };
                
                var modifyView = new ModifyView();
                modifyView.Show();
                Messenger.Default.Send(m);
            }
        }

        public void ResetTextBoxValues()
        {
            selectedCustomer = null;
            id = null;
            name = null;
            address = null;
            city = null;
            state = null;
            zip = null;
            RaisePropertyChanged("Name");
            RaisePropertyChanged("Address");
            RaisePropertyChanged("City");
            RaisePropertyChanged("State");
            RaisePropertyChanged("ID");
            RaisePropertyChanged("ZipCode");
        }

        public void SendDeleteMessage()
        {
            DataMessage m = new DataMessage()
            {
                CommandText = "Deleted",
                IDText = null,
                NameText = null,
                AddressText = null,
                CityText = null,
                StateText = null,
                ZipCodeText = null
            };
            Messenger.Default.Send(m);
        }

        public void DeleteCustomerMethod()
        {
            if (id == null || address == null || city == null || state == null || zip == null)
            {
                MessageBox.Show("Select a customer first");
            }
            else
            {
                var query = from cust in MMABookEntity.BookEntity.Customers where cust.CustomerID.ToString() == id select cust;
                selectedCustomer = query.FirstOrDefault();
                try
                {
                    if (MessageBox.Show("Confirm delete: " + selectedCustomer.Name + "?", "Confirm Delete", MessageBoxButton.OKCancel, MessageBoxImage.Question) == MessageBoxResult.OK)
                    {
                        MMABookEntity.BookEntity.Customers.Remove(selectedCustomer);
                        MMABookEntity.BookEntity.SaveChanges();
                        MMABookEntity.BookEntity.Entry(selectedCustomer).State = EntityState.Detached;
                        SendDeleteMessage();
                    }
                }
                catch (DbUpdateConcurrencyException dbe)
                {
                    dbe.Entries.Single().Reload();
                    if (MMABookEntity.BookEntity.Entry(selectedCustomer).State == EntityState.Detached)
                    {
                        MessageBox.Show("Another user has deleted that customer.", "Concurrency Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        SendDeleteMessage();
                    }
                    else
                    {
                        MessageBox.Show("Another user has updated that customer.", "Concurrency Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        DataMessage m = new DataMessage()
                        {
                            CommandText = "Modifications Complete",
                            IDText = selectedCustomer.CustomerID,
                            NameText = null,
                            AddressText = null,
                            CityText = null,
                            StateText = null,
                            ZipCodeText = null
                        };
                        Messenger.Default.Send(m);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, ex.GetType().ToString());
                }
            }
        }

        public void ExitMethod()
        {
            MMABookEntity.BookEntity.SaveChanges();
            System.Windows.Application.Current.Shutdown();
        }

        public void GetCustomerMethod()
        {
            if (!Validator.IsInt32(id))
            {
                ResetTextBoxValues();
            }
            else
            {
                var query = from cust in MMABookEntity.BookEntity.Customers
                            where cust.CustomerID.ToString() == id
                            select cust;
                selectedCustomer = query.FirstOrDefault();
                if (selectedCustomer == null)
                {
                    MessageBox.Show("A customer with that ID does not exist.");
                    ResetTextBoxValues();
                }
                else
                {
                    try
                    {
                        name = selectedCustomer.Name;
                        city = selectedCustomer.City;
                        address = selectedCustomer.Address;
                        state = selectedCustomer.State;
                        zip = selectedCustomer.ZipCode;
                        RaisePropertyChanged("Name");
                        RaisePropertyChanged("City");
                        RaisePropertyChanged("Address");
                        RaisePropertyChanged("State");
                        RaisePropertyChanged("ZipCode");
                    }
                    catch (DbUpdateConcurrencyException dbe)
                    {
                        dbe.Entries.Single().Reload();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, ex.GetType().ToString());
                    }
                } 
            }
        }
    }
}