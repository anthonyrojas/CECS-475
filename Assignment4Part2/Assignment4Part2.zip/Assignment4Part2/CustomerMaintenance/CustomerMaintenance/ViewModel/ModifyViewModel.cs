﻿using GalaSoft.MvvmLight;
using CustomerMaintenance.Model;
using System.Windows.Input;
using System.Data;
using GalaSoft.MvvmLight.Messaging;
using GalaSoft.MvvmLight.Threading;
using GalaSoft.MvvmLight.Command;
using CustomerMaintenance.Views;
using System.Windows;
using System.Linq;
using System;
using CustomerMaintenance.Messages;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace CustomerMaintenance.ViewModel
{
    public class ModifyViewModel : ViewModelBase
    {
        private int? id;
        private string name;
        private string address;
        private string city;
        private string state;
        private string zipCode;
        static Customer selectedCustomer;
        private ObservableCollection<string> stateList;
        public ICommand SaveChangesCommand { get; private set; }
        public ICommand CancelCommand { get; private set; }
        public ModifyViewModel()
        {
            
            stateList = new ObservableCollection<string>();
            var query = from states in MMABookEntity.BookEntity.States select states.StateName;
            var result = query.ToList();
            foreach (string r in result)
            {
                stateList.Add(r);
            }
            RaisePropertyChanged("StateList");
            
            Messenger.Default.Register<DataMessage>(this, OnReceiveMessageAction);
            SaveChangesCommand = new RelayCommand<IClosable>(this.SaveChangesMethod);
            CancelCommand = new RelayCommand<IClosable>(this.CancelMethod);
        }

        public void OnReceiveMessageAction(DataMessage m)
        {
            if (m.CommandText == "Modify")
            {
                selectedCustomer = m.CustomerMsg;
                id = m.CustomerMsg.CustomerID;
                name = m.CustomerMsg.Name;
                address = m.CustomerMsg.Address;
                city = m.CustomerMsg.City;
                var stateQuery = from states in MMABookEntity.BookEntity.States where states.StateCode == m.CustomerMsg.State select states.StateName;
                state = stateQuery.FirstOrDefault().ToString();
                zipCode = m.CustomerMsg.ZipCode;
            }
            RaiseChanges();
        }

        public void RaiseChanges()
        {
            RaisePropertyChanged("ID");
            RaisePropertyChanged("Name");
            RaisePropertyChanged("Address");
            RaisePropertyChanged("City");
            RaisePropertyChanged("State");
            RaisePropertyChanged("ZipCode");
        }

        public int? ID
        {
            get { return id; }
            set
            {
                id = value;
                RaisePropertyChanged("ID");
            }
        }

        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                RaisePropertyChanged("Name");
            }
        }

        public string Address
        {
            get { return address; }
            set
            {
                address = value;
                RaisePropertyChanged("Address");
            }
        }

        public string City
        {
            get { return city; }
            set
            {
                city = value;
                RaisePropertyChanged("City");
            }
        }

        public string State
        {
            get { return state; }
            set
            {
                state = value;
                RaisePropertyChanged("State");
            }
        }

        public string ZipCode
        {
            get { return zipCode; }
            set
            {
                zipCode = value;
                RaisePropertyChanged("ZipCode");
            }
        }

        public ObservableCollection<string> StateList
        {
            get { return stateList; }
            set
            {
                stateList = value;
                RaisePropertyChanged("StateList");
            }
        }

        public void SaveChangesMethod(IClosable window)
        {
            RaiseChanges();
            if (
                Validator.IsPresent("Name", name)
                && Validator.IsPresent("Address", address)
                && Validator.IsPresent("City", city)
                && Validator.IsPresent("State", state)
                && Validator.IsPresent("Zip Code", zipCode)
                && Validator.IsValidZipCode(zipCode)
                )
            {
                var stateQuery = from states in MMABookEntity.BookEntity.States where states.StateName == state select states.StateCode;
                string stateCode = stateQuery.FirstOrDefault().ToString();
                selectedCustomer.CustomerID = Convert.ToInt32(id);
                selectedCustomer.Name = name;
                selectedCustomer.Address = address;
                selectedCustomer.City = city;
                selectedCustomer.State = stateCode;
                selectedCustomer.ZipCode = zipCode;
                try
                {
                    MMABookEntity.BookEntity.SaveChanges();
                    MessageBox.Show("Customer modified", "Changes Saved", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                    DataMessage m = new DataMessage()
                    {
                        CommandText = "Modifications Complete",
                        IDText = selectedCustomer.CustomerID,
                        NameText = selectedCustomer.Name,
                        AddressText = selectedCustomer.Address,
                        CityText = selectedCustomer.City,
                        StateText = selectedCustomer.State,
                        ZipCodeText = selectedCustomer.ZipCode
                    };
                    Messenger.Default.Send(m);
                    window.Close();
                }
                catch (DbUpdateConcurrencyException dbe)
                {
                    dbe.Entries.Single().Reload();
                    if (MMABookEntity.BookEntity.Entry(selectedCustomer).State == EntityState.Detached)
                    {
                        MessageBox.Show("Another user has deleted that customer.", "Concurrency Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        DataMessage m = new DataMessage()
                        {
                            CommandText = "Deleted",
                            IDText = null,
                            NameText = null,
                            AddressText = null,
                            CityText = null,
                            StateText = null,
                            ZipCodeText = null
                        };
                        Messenger.Default.Send(m);
                    }
                    else
                    {
                        MessageBox.Show("Another user has updated that customer.", "Concurrency Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        DataMessage m = new DataMessage()
                        {
                            CommandText = "Modifications Complete",
                            IDText = selectedCustomer.CustomerID,
                            NameText = null,
                            AddressText = null,
                            CityText = null,
                            StateText = null,
                            ZipCodeText = null
                        };
                        Messenger.Default.Send(m);
                    }
                    window.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, ex.GetType().ToString());
                    window.Close();
                }
            }          
        }

        public void CancelMethod(IClosable window)
        {
            if(window != null)
            {
                window.Close();
            }
        }
    }
}
