﻿using GalaSoft.MvvmLight;
using CustomerMaintenance.Model;
using System.Windows.Input;
using System.Data;
using GalaSoft.MvvmLight.Messaging;
using GalaSoft.MvvmLight.Threading;
using GalaSoft.MvvmLight.Command;
using CustomerMaintenance.Views;
using System.Windows;
using System.Linq;
using System;
using CustomerMaintenance.Messages;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;

namespace CustomerMaintenance.ViewModel
{
    public class AddViewModel : ViewModelBase
    {
        private ObservableCollection<string> stateList;
        public ICommand AddCustomerCommand { get; private set; }
        public ICommand CancelCommand { get; private set; }

        private int id;
        private string name;
        private string address;
        private string city;
        private string state;
        private string zipCode;

        public AddViewModel()
        {
            stateList = new ObservableCollection<string>();
            var query = from states in MMABookEntity.BookEntity.States select states.StateName;
            var result = query.ToList();
            foreach(string r in result)
            {
                stateList.Add(r);
            }
            RaisePropertyChanged("StateList");
            AddCustomerCommand = new RelayCommand<IClosable>(this.AddCustomerMethod);
            CancelCommand = new RelayCommand<IClosable>(this.CancelMethod);;
        }
        public ObservableCollection<string> StateList
        {
            get{ return stateList; }
            set
            {
                stateList = value;
                RaisePropertyChanged("StateList");
            }
        }

        public int ID
        {
            get { return id; }
            set
            {
                id = value;
                RaisePropertyChanged("ID");
            }
        }

        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                RaisePropertyChanged("Name");
            }
        }

        public string Address
        {
            get { return address; }
            set
            {
                address = value;
                RaisePropertyChanged("Address");
            }
        }

        public string City
        {
            get { return city; }
            set
            {
                city = value;
                RaisePropertyChanged("City");
            }
        }

        public string State
        {
            get { return state; }
            set
            {
                state = value;
                RaisePropertyChanged("State");
            }
        }

        public string ZipCode
        {
            get { return zipCode; }
            set
            {
                zipCode = value;
                RaisePropertyChanged("ZipCode");
            }
        }

        public void AddCustomerMethod(IClosable window)
        {
            if (
                Validator.IsPresent("Name", name)
                && Validator.IsPresent("Address", address)
                && Validator.IsPresent("City", city)
                && Validator.IsPresent("State", state)
                && Validator.IsPresent("ZipCode", zipCode)
                && Validator.IsValidZipCode(zipCode)
                )
            {
                var stateQuery = from states in MMABookEntity.BookEntity.States where states.StateName == state select states.StateCode;
                string stateCode = stateQuery.FirstOrDefault();
                var idQuery = from cust in MMABookEntity.BookEntity.Customers orderby cust.CustomerID descending select cust.CustomerID;
                id = idQuery.FirstOrDefault();
                Customer c = new Customer
                {
                    CustomerID = id + 1,
                    Name = name,
                    Address = address,
                    City = city,
                    State = stateCode,
                    ZipCode = zipCode,
                };
                MMABookEntity.BookEntity.Customers.Add(c);
                //MMABookEntity.BookEntity.Entry(c).State = EntityState.Added;
                try
                {
                    MMABookEntity.BookEntity.SaveChanges();
                    string customerString = String.Format("ID: {0}\nName: {1}\nAddress: {2}\nCity: {3}\nState: {4}\nZipCode: {5}", c.CustomerID, c.Name, c.Address, c.City, state, c.ZipCode);
                    MessageBox.Show(customerString, "Customer Added", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
                if (window != null)
                {
                    ResetValues();
                    window.Close();
                }
            }
        }

        public void CancelMethod(IClosable window)
        {
            if (window != null)
            {
                ResetValues();
                window.Close();
            }
        }

        public void ResetValues()
        {
            id = 0;
            name = null;
            address = null;
            city = null;
            state = null;
            zipCode = null;
            RaisePropertyChanged("ID");
            RaisePropertyChanged("Name");
            RaisePropertyChanged("Address");
            RaisePropertyChanged("City");
            RaisePropertyChanged("State");
            RaisePropertyChanged("ZipCode");
        }
    }
}
